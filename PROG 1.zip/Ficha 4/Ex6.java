public class Ex6 {
    public static void main(String[] args) {
        int numero = 1;

        while (numero <= 100) {
            System.out.println(numero);
            numero++;
        }
    }
}
