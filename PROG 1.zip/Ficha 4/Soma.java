public class Soma{
	public static void main(String[]args){
	
	 int soma = 0;
	
	 for(int c = 0; c <= 9; c++ ){
	 soma += c;
	 }
	 System.out.println("A soma dos numeros no intervalo de 1 a 9 e:" +soma);
	}
}