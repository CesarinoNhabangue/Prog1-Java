public class Circunferencia {
    public static void main(String[] args) {
        double raio = 12; // Raio da circunferência
        double area = 3.14 * Math.pow(raio, 2);
        double comprimento = 2 * 3.14 * raio;

        System.out.println("Área da Circunferência: " + area);
        System.out.println("Comprimento da Circunferência: " + comprimento);
    }
}
