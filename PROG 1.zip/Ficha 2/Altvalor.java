public class Altvalor{
    public static void main(String[]args){
        int numero = 10;
        System.out.println("numero:" +numero);

        numero = 20;
        System.out.println("numero:" +numero);

        numero = 30;
        System.out.println("numero:" +numero);
    }
}