public class Programa1 {
    public static void main(String[]args){
        System.out.println("OlA, este e o primeiro programa em Java"); 
        System.out.println("O meu nome e Cesarino Teodoro Nhabangue Junior"); 
    }
}
