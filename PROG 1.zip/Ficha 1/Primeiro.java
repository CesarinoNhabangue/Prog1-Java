public class Primeiro {
    public static void main(String[]args){
        System.out.println("Este e o primeiro programa em Java"); //imprimir no ecra
    }
}
