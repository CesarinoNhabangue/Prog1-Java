public class HorarioAulas {
    public static void main(String[] args) {

        System.out.println("Horário de Aulas\n");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println("| Hora/dias |    Segunda-Feira    |     Terca-Feira     |    Quarta-Feira    |     Quinta-Feira    |      Sexta-Feira    |       Sabado        |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|07:20-08:20|                     |Algoritimo e logica  |                    |Algoritimo e Logica  |                     |Probabilidade e      |");
        System.out.println("|           |                     |de Programacao       |                    |de Programacao       |                     |Estatitisca          |");
        System.out.println("|08:20-09:20|                     |Sala 116             |                    |Sala 202             |                     |Sala 116             |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|09:20-10:20|                     |Analise Matematica II|                    |Analise Matematica II|                     |Ingles Tecnico       |");
        System.out.println("|10:20-11:20|                     |Sala 116             |                    |Sala 202             |                     |Sala 116             |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|11:20-12:20|                     |Programacao I        |                    |Ingles Tecnico       |Matematica Discreta  |                     |");
        System.out.println("|12:20-13:20|                     |SI2                  |                    |Sala 202             |Sala 120             |                     |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|13:20-14:20|Probabilidade e      |                     |Ingles              |                     |Programacao I        |                     |");
        System.out.println("|           |Estatistica          |                     |Tecnico             |                     |                     |                     |");
        System.out.println("|14:20-15:20|Sala 116             |                     |SI1                 |                     |SI2                  |                     |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|15:20-16:20|Matematica Discreta  |                     |Programacao I       |                     |Analise Matematica II|                     |");
        System.out.println("|16:20-17:20|Sala 116             |                     |SI3                 |                     |Sala 117             |                     |");
        System.out.println("|-----------|---------------------|---------------------|--------------------|---------------------|---------------------|---------------------|");
        System.out.println("|17:20-18:20|                     |                     |                    |                     |                     |                     |");
        System.out.println("|18:20-19:20|                     |                     |                    |                     |                     |                     |");
        System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------");
    }
}

