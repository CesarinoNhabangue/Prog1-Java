//PARTE 1

import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] dias = new int[31];
        int[] semanas = new int[31];
        double[] temperaturas = new double[31];

        int opcao;
        do {
            System.out.println("Menu:");
            System.out.println("1. Preenchimento das temperaturas");
            System.out.println("2. Mostrar as temperaturas");
            System.out.println("3. Visualizar a temperatura media do mes");
            System.out.println("4. Dia ou dias mais quentes do mes");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opcao: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    preencherTemperaturas(dias, semanas, temperaturas);
                    break;
                case 2:
                    mostrarTemperaturas(dias, semanas, temperaturas);
                    break;
                case 3:
                    visualizarMedia(temperaturas);
                    break;
                case 4:
                    encontrarDiaMaisQuente(dias, semanas, temperaturas);
                    break;
                case 5:
                    System.out.println("Saindo do programa.");
                    break;
                default:
                    System.out.println("Opção invalida. Escolha novamente.");
            }
        } while (opcao != 5);
    }
//PARTE 2
    public static void preencherTemperaturas(int[] dias, int[] semanas, double[] temperaturas) {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 31; i++) {
            System.out.println("Dia " + (i + 1) + ":");
            System.out.print("Numero do dia do mes: ");
            dias[i] = scanner.nextInt();
            System.out.print("Semana: ");
            semanas[i] = scanner.nextInt();
            System.out.print("Temperatura media: ");
            temperaturas[i] = scanner.nextDouble();
        }
        System.out.println("Temperaturas preenchidas com sucesso.");
    }
    public static void mostrarTemperaturas(int[] dias, int[] semanas, double[] temperaturas) {
        for (int i = 0; i < 31; i++) {
            System.out.println("Dia " + dias[i] + ":");
            System.out.println("Semana: " + semanas[i]);
            System.out.println("Temperatura media: " + temperaturas[i] + " graus");
        }
    }
    public static void visualizarMedia(double[] temperaturas) {
        double media = calcularMedia(temperaturas);
        System.out.println("Temperatura media do mes: " + media + " graus");
    }
    public static void encontrarDiaMaisQuente(int[] dias, int[] semanas, double[] temperaturas) {
        double maxTemp = -Double.MAX_VALUE;
        int diaMaisQuente = -1;
        for (int i = 0; i < 31; i++) {
           if (temperaturas[i] > maxTemp) {
                maxTemp = temperaturas[i];
                diaMaisQuente = i;
            }
        }
        if (diaMaisQuente != -1) {
            System.out.println("O dia mais quente foi:");
            System.out.println("Dia " + dias[diaMaisQuente] + ", " +
                    "semana " + semanas[diaMaisQuente] + " com " +
                    temperaturas[diaMaisQuente] + " graus.");
        }
    }
    public static double calcularMedia(double[] temperaturas) {
        double soma = 0;
        for (double temp : temperaturas) {
            soma += temp;
        }
        return soma / temperaturas.length;
    }
}