public class Ex1 {
    public static void main(String[] args) {
        String str = "ZYWXVUTSRQPONMLKJIHGFEDCBA";
        for (int i = 0; i < str.length(); i++) {
            System.out.println(str.substring(i));
        }
    }
}
